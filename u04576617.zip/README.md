# COS214_P4

run "sudo apt-get install libsfml-dev" to be able use the program

To Do list:
- [ ] Add fertilizer truck
- [ ] Add Crop Collector truck
- [ ] Add depth first traversal
- [ ] Add traversal functions ( nextFarm() , end() ...etc)
- [ ] Add HUD to allow buing plots , extrabarns and managing farm
- [ ] UML

Idea

Make the player choose using depth first or breadth first , and allocate an individual truck to each cropfield.
So the player will go to each cropfield one by one using a traversal strategy and choose what to do at the selected cropfield ( buy trucks , harvest , add barn...etc)
